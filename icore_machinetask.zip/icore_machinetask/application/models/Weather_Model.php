<?php 

class Weather_Model extends CI_Model
{
	public function get_weather_report($table)
	{
        $this->db->select('locations.locations_id, locations.location, weather_reports.temperature, weather_reports.weather_condition, weather_reports.updated_at');
        $this->db->from('locations');
        $this->db->join('weather_reports', 'locations.locations_id = weather_reports.locations_id', 'left');
        return $this->db->get()->result_array();
	}

	public function get_location_by_id($location_id){
       $this->db->select('*');
       $this->db->from('locations');
       $this->db->where('locations_id', $location_id);
       return $this->db->get()->row_array();
	}

	public function update_weather($location_id, $weather_data) {

        $this->db->where('locations_id', $location_id);
        $this->db->update('weather_reports', [
            'temperature' => $weather_data['temperature'],
            'weather_condition' => $weather_data['weather_condition'],
            'updated_at' => $weather_data['updated_at']
        ]);
        return $this->db->affected_rows();
    }

}
?>