<?php
class WeatherCronModel extends CI_Model {

    public function get_all_locations() {
        return $this->db->get('locations')->result_array();
    }

    public function update_weather($location_id, $weather_data) {
        $data = [
            'temperature' => $weather_data['temperature'],
            'weather_condition' => $weather_data['weather_condition'],
            'updated_at' => $weather_data['updated_at']
        ];
        $this->db->where('locations_id', $location_id);
        $this->db->update('weather_reports', $data);
    }
}
