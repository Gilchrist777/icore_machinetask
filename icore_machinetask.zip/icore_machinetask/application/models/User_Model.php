<?php 

class User_Model extends CI_Model
{
	public function check_user($table, $email, $password)
	{
      $this->db->select('*');
      $this->db->from($table);
      $this->db->where('email', $email);
      $this->db->where('password', $password);
      $query = $this->db->get();
      $result = $query->result_array();
      if(!empty($result)){
        return $result;
      } else {
      	return '2';
      }
	}

  public function save_user_detail($table, $data)
  {
    $this->db->insert($table, $data);
    $location_id = $this->db->insert_id(); 

      $weather_data = [
        'locations_id' => $location_id,
        'temperature' => null,
        'weather_condition' => 'Fetching...',
        'updated_at' => date('Y-m-d H:i:s')
    ];

    $this->db->insert('weather_reports', $weather_data);
  }
}

?>