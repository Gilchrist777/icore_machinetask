<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('weather_Model');
	}

	public function weather_report()
	{
		$data['get_location_details'] = $this->weather_Model->get_weather_report('locations');
		$this->load->view('weather_report', $data);
	}

	public function refresh_weather()
	{ 
        $location_id = $this->uri->segment(3); 
        $location = $this->weather_Model->get_location_by_id($location_id);
       
        if ($location) {
            $weather_data = $this->fetch_weather($location['latitude'], $location['longitude']);
            $this->weather_Model->update_weather($location_id, $weather_data);
            echo json_encode(['status' => 'success', 'weather' => $weather_data]);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Location not found']);
        }
	}

	private function fetch_weather($latitude, $longitude) 
	{
	    $apiKey = 'a93542fa8495031270fd0b08b00b4e4f';
	    $url = "https://api.openweathermap.org/data/2.5/weather?lat={$latitude}&lon={$longitude}&appid={$apiKey}&units=metric";
	  
	    $ch = curl_init();
	    curl_setopt($ch, CURLOPT_URL, $url);
	    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

	    $response = curl_exec($ch);
	    curl_close($ch);
	    $weatherData = json_decode($response, true);
        
	    if ($weatherData && isset($weatherData['main']['temp'])) {
	        return [
	            'temperature' => $weatherData['main']['temp'], 
	            'weather_condition' => $weatherData['weather'][0]['description'],
	            'updated_at' => date('Y-m-d H:i:s')
	        ];
	    } else {
	        return [
	            'temperature' => null,
	            'weather_condition' => 'Data not available',
	            'updated_at' => date('Y-m-d H:i:s')
	        ];
	    }
    }
 }
?>