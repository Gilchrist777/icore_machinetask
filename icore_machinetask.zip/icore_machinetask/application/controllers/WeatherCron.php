<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class WeatherCron extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('WeatherCronmodel'); // Load model
    }

    public function update_weather_reports() {
        $locations = $this->WeatherCronmodel->get_all_locations();
        //echo"<pre>";print_r($locations);exit;
        foreach ($locations as $location) {
           
            $weather_data = $this->fetch_weather($location['latitude'], $location['longitude']);

            $this->WeatherCronmodel->update_weather($location['locations_id'], $weather_data);
        }
            echo "Weather reports updated successfully.";
    }

    private function fetch_weather($latitude, $longitude) {
        $apiKey = 'a93542fa8495031270fd0b08b00b4e4f';
        $url = "https://api.openweathermap.org/data/2.5/weather?lat={$latitude}&lon={$longitude}&appid={$apiKey}&units=metric";

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        curl_close($ch);

        $weatherData = json_decode($response, true);

        if ($weatherData && isset($weatherData['main']['temp'])) {
            return [
                'temperature' => $weatherData['main']['temp'],
                'weather_condition' => $weatherData['weather'][0]['description'],
                'updated_at' => date('Y-m-d H:i:s')
            ];
        } else {
            return [
                'temperature' => null,
                'weather_condition' => 'Data not available',
                'updated_at' => date('Y-m-d H:i:s')
            ];
        }
    }
}
