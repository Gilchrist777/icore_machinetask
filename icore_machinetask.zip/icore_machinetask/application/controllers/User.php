<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('user_Model');
	}

	public function index()
	{
		$this->load->view('user_login');
	}

    public function add_locations()
	{
	   $email = $this->input->post('email');
	   $password = $this->input->post('password');
	   $check_user = $this->user_Model->check_user('users', $email, $password);
       if($check_user == 2){
        $this->session->set_flashdata('error', 'Email or Password in Incorrect');
        redirect();
       } else {
       	$user_id = $check_user[0]['user_id'];
       	  $this->session->set_userdata('user_id', $user_id);
          $this->load->view('add_locations');
        }
	}
	public function location_save()
	{
		$user_id = $this->session->userdata('user_id');
		$this->form_validation->set_rules('location', 'Location', 'required');
		$this->form_validation->set_rules('latitude', 'Latitude', 'required|numeric');
		$this->form_validation->set_rules('longitude', 'Longitude', 'required|numeric');

		if($this->form_validation->run() === FALSE){
             $this->load->view('add_locations');
		} else {
            $data = array(
               'user_id' => $user_id,
               'location' => $this->input->post('location'),
               'latitude' => $this->input->post('latitude'),
               'longitude' => $this->input->post('longitude'),
            );
            $save_user_detail = $this->user_Model->save_user_detail('locations', $data);
            $this->session->set_flashdata('success', 'Location details saved Successfully');
            redirect('location-save');
		}
	}

}
