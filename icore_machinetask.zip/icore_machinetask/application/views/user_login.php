<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>User Login</title>
</head>
<body>
	<?php 
      if($this->session->flashdata('error')) { ?>
      	<div class="alert alert-danger">
           <?php echo $this->session->flashdata('error'); ?>
       </div>
     <?php } ?>
	<h2>User Login</h2>
  <form action="<?php echo base_url('add-locations');?>" method="POST">
    <div>
  	 <label>Email</label>
	 <input type="email" name="email" id="email"></br></br>
	 <label>Password</label>
	 <input type="password" name="password" id="password" pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$"></br></br>
	 <button type="submit">Submit</button>
    </div>
  <form> 
</body>
</html>