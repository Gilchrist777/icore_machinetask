<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Add Locations</title>
	<style>
       .error
         { 
         	color: red; 
         	font-size: 14px;
         }

    </style>
</head>
<body>
	<?php 
      if($this->session->flashdata('success')) { ?>
      	<div class="alert alert-success">
           <?php echo $this->session->flashdata('success'); ?>
       </div>
     <?php } ?>
 <h2>Fill Details</h2>
 <form action="<?php echo base_url('location-save');?>" method="POST">
 <div>
 	<label>Location</label>
 	<input type="text" name="location" id="location" value="<?php echo set_value('location'); ?>"></br>
 	<span style="color: red; font-size: 14px;"><?php echo form_error('location')?></span></br>
 	<label>Latitude</label>
 	<input type="text" name="latitude" id="latitude" oninput="validateLatitude()" ><span id="lat-error" class="error"></span></br>
 	<span style="color: red; font-size: 14px;"><?php echo form_error('latitude')?></span></br>
 	<label>Longitude</label>
 	<input type="text" name="longitude" id="longitude" oninput="validateLongitude()" ><span id="lon-error" class="error"></span></br>
 	<span style="color: red; font-size: 14px;"><?php echo form_error('longitude')?></span></br>
 	<button type="submit">Submit</button>
 </form>
 </div>

<script>
        function validateLatitude() {
            let latInput = document.getElementById("latitude");
            let latError = document.getElementById("lat-error");
            let latitude = parseFloat(latInput.value);

	            if (isNaN(latitude) && latInput.value !== '') {
	        // If not a number and input is not empty, show alert
	        latError.textContent = "Please enter a valid number.";
	        latError.textContent = "Latitude must be a number.";
	        return; // Exit the function to prevent further checks
	        }

		    // Validate Latitude is within the range of -90 to 90
		    if (latitude < -90 || latitude > 90) {
		        latError.textContent = "Latitude must be between -90 and 90.";
		    } else {
		        // If input is valid, remove the error message
		        latError.textContent = '';
		    }

        }

        function validateLongitude() {
           let lonInput = document.getElementById("longitude");
           let lonError = document.getElementById("lon-error");
           let longitude = parseFloat(lonInput.value);

            // Validate Longitude
            if (isNaN(longitude) && lonInput.value !== '') {
                lonError.textContent = "Please enter a valid number.";
	            lonError.textContent = "Longitude must be a number.";
                return; // Exit the function to prevent further checks
            } 

            if (longitude < -180 || longitude > 180) {
            	lonError.textContent = "Longitude must be between -180 and 180";
            }
            else {
                lonError.textContent = '';
        }
     }
    </script>
</body>
</html>