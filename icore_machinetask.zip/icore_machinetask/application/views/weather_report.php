<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Weather Report</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<h2>Weather Report</h2>

<div>
	<table class="table table-bordered">
		<thead>
			<tr>
			<th>Location Name</th>
            <th>Temperature</th>
            <th>Weather Condition</th>
            <th>Last Updated</th>
            <th>Action</th>
		  </tr>
		</thead>
		<tbody>
			<?php foreach ($get_location_details as $get_location_detail) { ?>
			  <tr id="row_<?php echo $get_location_detail['locations_id']; ?>">
				<td><?php echo $get_location_detail['location']; ?></td>
				<td class="temperature"><?php echo $get_location_detail['temperature']; ?>°C</td>
				<td class="weather-condition"><?php echo $get_location_detail['weather_condition']; ?></td>
                <td class="last-updated"><?php echo $get_location_detail['updated_at'];?></td>
                <td><button class="btn btn-primary refresh-btn" data-locations_id="<?php echo $get_location_detail['locations_id']; ?>">Refresh</button></td>
			 </tr>
				<?php } ?>
		</tbody>
	  </table>
    </div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script type="text/javascript">
      $(document).ready(function() {
       $('.refresh-btn').click(function() {
        var locations_id = $(this).data('locations_id');
        $.ajax({
         url: '<?= base_url('dashboard/refresh_weather/') ?>' + locations_id,
         method: 'GET',
         dataType: 'json',
         success: function(response) {
         	console.log(response);
         	if (response.status === 'success') {
                var row = $('#row_' + locations_id);
                    row.find('.temperature').text(response.weather.temperature + " °C");
                    row.find('.weather-condition').text(response.weather.weather_condition);
                    row.find('.last-updated').text(response.weather.updated_at);
            } else {
            	 alert(response.message);
             } },
	         error: function(xhr, status, error) {
        			console.error("AJAX Error: " + error);
    			}
        });
    });
  });
    </script>

     <script>
        // Initialize Pusher
        var pusher = new Pusher('your-key', {
            cluster: 'your-cluster'
        });

        // Subscribe to the weather channel
        var channel = pusher.subscribe('weather_channel');

        // Listen for weather updates
        channel.bind('weather_update', function(data) {
            console.log('New weather update:', data);
            document.getElementById('weather-status').innerHTML = 
                `Temperature: ${data.temperature}, Humidity: ${data.weather_condition}, Last-updated: ${data.updated_at}`;
        });
    </script>
  </body>
</html>